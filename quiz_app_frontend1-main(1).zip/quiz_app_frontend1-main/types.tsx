export interface FormType{
    user_name: string,
    user_email: string,
    user_password: string

}


